create function age(timestamp without time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
RETURN age((CURRENT_DATE)::timestamp without time zone, $1);

comment on function age(timestamp) is 'date difference from today preserving months and years';

alter function age(timestamp) owner to postgres;

